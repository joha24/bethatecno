# Betha MakerBook
## Sistema de Gestión de Espacios Tecnológicos – Hogar de Bethania

Primera versión frontend para GitHub Pages.

### Incluye
- Login por usuario y contraseña.
- Roles: Administrador, Docente y Directivo.
- Aula Maker y Pizarra Interactiva.
- Reservas con fecha, sala, hora de inicio, hora de finalización, docente y curso.
- Bloqueo automático de reservas superpuestas.
- Aprobación automática si el horario está disponible.
- Vista mensual de calendario.
- Agenda diaria y semanal.
- Avisos/notificaciones dentro de la página.
- Panel de administración.
- Gestión de usuarios, espacios y cursos.
- Reportes básicos.
- Diseño responsive para PC, tablet y celular.
- Datos persistidos en localStorage.

### Usuarios iniciales
- Administrador: `admin` / `admin123`
- Docente: `docente` / `docente123`
- Directivo: `directivo` / `directivo123`

### Importante
Esta versión es un prototipo funcional 100% frontend. Los usuarios, contraseñas y reservas se guardan en el navegador mediante `localStorage`. Esto NO constituye autenticación segura para producción.

Para convertirlo en un sistema real multiusuario, el siguiente paso es reemplazar `localStorage` por un backend y una base de datos (por ejemplo Supabase/Firebase/otra opción), manteniendo la interfaz actual.

### Publicar en GitHub Pages
1. Crear un repositorio en GitHub.
2. Subir toda la carpeta respetando su estructura.
3. En Settings → Pages, seleccionar el branch principal y la carpeta raíz `/`.
4. Guardar y esperar la publicación.

Si el repositorio es público, el sitio también será accesible públicamente. GitHub Pages no debe usarse como almacenamiento seguro de contraseñas.
