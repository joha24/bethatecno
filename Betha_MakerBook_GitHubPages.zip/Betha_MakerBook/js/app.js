const KEY = "bethaMakerBookData_v1";
const SESSION_KEY = "bethaMakerBookSession_v1";

const defaultData = {
  users: [
    {id:"u1",name:"Administrador Bethania",username:"admin",password:"admin123",role:"Administrador"},
    {id:"u2",name:"Docente de Tecnología",username:"docente",password:"docente123",role:"Docente"},
    {id:"u3",name:"Equipo Directivo",username:"directivo",password:"directivo123",role:"Directivo"}
  ],
  rooms: [
    {id:"r1",name:"Aula Maker",description:"Espacio para programación, robótica, electrónica y proyectos maker.",capacity:30,resources:["10 micro:bit","Arduino Uno","Impresora 3D","Kits de electrónica","Motores","Servomotores"]},
    {id:"r2",name:"Pizarra Interactiva",description:"Espacio equipado para clases interactivas, presentaciones y actividades digitales.",capacity:35,resources:["Pizarra interactiva","Proyector","PC","Audio","Internet"]}
  ],
  courses:["Sala 3","1° Grado","2° Grado","3° Grado","4° Grado","5° Grado","6° Grado","7° Grado","1° Año Secundaria","2° Año Secundaria"],
  reservations:[],
  notices:[]
};

let data, currentUser, currentSection="dashboard", calendarDate=new Date(), agendaDate=new Date(), agendaView="day";

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const todayISO = () => new Date().toISOString().slice(0,10);
const pad = n => String(n).padStart(2,"0");
const dateISO = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const fmtDate = iso => new Date(iso+"T00:00:00").toLocaleDateString("es-AR",{day:"2-digit",month:"2-digit",year:"numeric"});
const fmtLong = iso => new Date(iso+"T00:00:00").toLocaleDateString("es-AR",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
const escapeHTML = s => String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const uid = prefix => prefix + Math.random().toString(36).slice(2,9);

function loadData(){
  try{ data=JSON.parse(localStorage.getItem(KEY)) || structuredClone(defaultData); }
  catch{ data=structuredClone(defaultData); }
  if(!data.reservations) data.reservations=[];
  if(!data.notices) data.notices=[];
}
function saveData(){localStorage.setItem(KEY,JSON.stringify(data));}
function showToast(msg,type=""){const el=document.createElement("div");el.className=`toast ${type}`;el.textContent=msg;$("#toastContainer").appendChild(el);setTimeout(()=>el.remove(),3200)}
function isAdmin(){return currentUser?.role==="Administrador"}
function canSeeAll(){return currentUser && ["Administrador","Directivo"].includes(currentUser.role)}
function visibleReservations(){return canSeeAll()?data.reservations:data.reservations.filter(r=>r.teacherId===currentUser.id)}
function userById(id){return data.users.find(u=>u.id===id)}
function roomById(id){return data.rooms.find(r=>r.id===id)}
function teacherName(id){return userById(id)?.name || "—"}

function login(){
  const username=$("#loginUser").value.trim(), password=$("#loginPassword").value;
  const user=data.users.find(u=>u.username===username && u.password===password);
  if(!user){$("#loginError").textContent="Usuario o contraseña incorrectos.";return}
  currentUser=user;localStorage.setItem(SESSION_KEY,user.id);$("#loginError").textContent="";showApp();showToast(`¡Bienvenido/a, ${user.name}!`,"success");
}
function restoreSession(){
  const id=localStorage.getItem(SESSION_KEY); currentUser=data.users.find(u=>u.id===id);
  if(currentUser) showApp(); else $("#loginView").classList.remove("hidden");
}
function showApp(){
  $("#loginView").classList.add("hidden");$("#appView").classList.remove("hidden");
  $("#sidebarName").textContent=currentUser.name;$("#sidebarRole").textContent=currentUser.role;
  $("#topUserName").textContent=currentUser.name.split(" ")[0];
  const initial=(currentUser.name||"U").charAt(0).toUpperCase();$("#sidebarAvatar").textContent=initial;$("#topAvatar").textContent=initial;
  $$(".admin-only").forEach(el=>el.classList.toggle("hidden",!isAdmin()));
  renderAll();goSection("dashboard");
}
function logout(){localStorage.removeItem(SESSION_KEY);currentUser=null;$("#appView").classList.add("hidden");$("#loginView").classList.remove("hidden");$("#loginForm").reset()}
function goSection(section){
  if(section==="admin"&&!isAdmin()){showToast("Solo el administrador puede acceder.","error");return}
  currentSection=section;
  $$(".page-section").forEach(s=>s.classList.add("hidden"));$(`#${section}Section`).classList.remove("hidden");
  $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.section===section));
  const titles={dashboard:"Inicio",reservas:"Reservas",calendario:"Calendario",agenda:"Agenda",salas:"Espacios",reportes:"Reportes",admin:"Administración"};
  $("#pageTitle").textContent=titles[section]||"Inicio";
  if(section==="calendario")renderCalendar();if(section==="agenda")renderAgenda();if(section==="reportes")renderReports();if(section==="admin")renderAdmin();
  $("#sidebar").classList.remove("open");
}
function renderAll(){renderDashboard();renderReservations();renderRooms();renderFilters();renderReports();renderNotifications();renderAdmin();}

function renderDashboard(){
  const visible=visibleReservations(), today=todayISO();
  $("#welcomeTitle").textContent=`Bienvenido/a, ${currentUser.name.split(" ")[0]}`;
  $("#statToday").textContent=visible.filter(r=>r.date===today).length;
  $("#statRooms").textContent=data.rooms.length;
  $("#statTeachers").textContent=data.users.filter(u=>["Docente","Administrador","Directivo"].includes(u.role)).length;
  $("#statActive").textContent=visible.filter(r=>r.status==="Aprobada").length;
  const list=visible.filter(r=>r.date>=today).sort(sortReservation).slice(0,6);
  $("#upcomingReservations").innerHTML=list.length?list.map(resCard).join(""):`<div class="empty">No hay próximas reservas.</div>`;
}
function sortReservation(a,b){return (a.date+a.start).localeCompare(b.date+b.start)}
function resCard(r){
  const room=roomById(r.roomId);
  return `<div class="reservation-item">
    <div class="time-block"><strong>${escapeHTML(r.start)}</strong><small>${fmtDate(r.date)}</small></div>
    <div class="res-main"><strong>${escapeHTML(room?.name||"Espacio")}</strong><span>${escapeHTML(teacherName(r.teacherId))} · ${escapeHTML(r.course)}</span></div>
    <span class="status ${r.status==="Aprobada"?"approved":"finished"}">${escapeHTML(r.status)}</span>
  </div>`;
}

function renderReservations(){
  const search=($("#reservationSearch")?.value||"").toLowerCase(), roomFilter=$("#reservationRoomFilter")?.value||"", status=$("#reservationStatusFilter")?.value||"";
  let list=visibleReservations().filter(r=>{
    const room=roomById(r.roomId)?.name||"", text=`${teacherName(r.teacherId)} ${r.course} ${room} ${r.activity||""}`.toLowerCase();
    return (!search||text.includes(search))&&(!roomFilter||r.roomId===roomFilter)&&(!status||r.status===status);
  }).sort(sortReservation);
  $("#reservationsTable").innerHTML=list.length?list.map(r=>`<tr>
    <td>${fmtDate(r.date)}</td><td>${r.start} – ${r.end}</td><td>${escapeHTML(roomById(r.roomId)?.name||"")}</td>
    <td>${escapeHTML(teacherName(r.teacherId))}</td><td>${escapeHTML(r.course)}</td>
    <td><span class="status ${r.status==="Aprobada"?"approved":"finished"}">${escapeHTML(r.status)}</span></td>
    <td><button class="row-action" data-detail="${r.id}">Ver</button>${isAdmin()?` <button class="row-action danger-action" data-delete="${r.id}">Eliminar</button>`:""}</td>
  </tr>`).join(""):`<tr><td colspan="7">No se encontraron reservas.</td></tr>`;
}
function renderFilters(){
  const options=data.rooms.map(r=>`<option value="${r.id}">${escapeHTML(r.name)}</option>`).join("");
  if($("#reservationRoomFilter"))$("#reservationRoomFilter").innerHTML=`<option value="">Todos los espacios</option>${options}`;
}
function populateReservationForm(){
  $("#rRoom").innerHTML=data.rooms.map(r=>`<option value="${r.id}">${escapeHTML(r.name)}</option>`).join("");
  $("#rTeacher").innerHTML=data.users.filter(u=>u.role==="Docente"||u.role==="Administrador").map(u=>`<option value="${u.id}">${escapeHTML(u.name)}</option>`).join("");
  $("#rCourse").innerHTML=data.courses.map(c=>`<option>${escapeHTML(c)}</option>`).join("");
  $("#rDate").value=todayISO();$("#rStart").value="08:00";$("#rEnd").value="09:00";
  $("#rTeacher").value=currentUser.role==="Docente"?currentUser.id:(data.users.find(u=>u.role==="Docente")?.id||currentUser.id);
  checkAvailability();
}
function openReservationModal(){populateReservationForm();$("#reservationModal").classList.remove("hidden")}
function checkAvailability(){
  const date=$("#rDate").value,roomId=$("#rRoom").value,start=$("#rStart").value,end=$("#rEnd").value,box=$("#availabilityBox");
  if(!date||!roomId||!start||!end){box.className="availability-box";box.textContent="Completá fecha, sala y horario para comprobar disponibilidad.";return false}
  if(start>=end){box.className="availability-box no";box.textContent="La hora de finalización debe ser posterior al inicio.";return false}
  const conflict=data.reservations.find(r=>r.date===date&&r.roomId===roomId&&r.status==="Aprobada"&&start<r.end&&end>r.start);
  if(conflict){box.className="availability-box no";box.textContent=`🚫 No disponible. Ya existe una reserva de ${conflict.start} a ${conflict.end}.`;return false}
  box.className="availability-box ok";box.textContent="✓ Espacio disponible. La reserva se aprobará automáticamente.";return true;
}
function createReservation(e){
  e.preventDefault();
  if(!checkAvailability()){showToast("No se puede reservar: el horario no está disponible.","error");return}
  const r={id:uid("res_"),date:$("#rDate").value,roomId:$("#rRoom").value,start:$("#rStart").value,end:$("#rEnd").value,teacherId:$("#rTeacher").value,course:$("#rCourse").value,activity:$("#rActivity").value.trim(),notes:$("#rNotes").value.trim(),status:"Aprobada",createdAt:new Date().toISOString()};
  data.reservations.push(r);
  data.notices.unshift({id:uid("n_"),text:`Reserva aprobada: ${roomById(r.roomId).name} · ${fmtDate(r.date)} · ${r.start}-${r.end}`,date:new Date().toISOString(),read:false});
  saveData();closeModal("reservationModal");renderAll();showToast("Reserva creada y aprobada automáticamente.","success");
}
function deleteReservation(id){
  const r=data.reservations.find(x=>x.id===id);if(!r)return;
  if(!isAdmin()){showToast("Solo el administrador puede eliminar reservas.","error");return}
  if(confirm("¿Eliminar esta reserva?")){data.reservations=data.reservations.filter(x=>x.id!==id);saveData();renderAll();showToast("Reserva eliminada.","success")}
}
function showDetail(id){
  const r=data.reservations.find(x=>x.id===id), room=roomById(r.roomId);if(!r)return;
  $("#detailContent").innerHTML=`<span class="eyebrow">DETALLE DE RESERVA</span><h2>${escapeHTML(room?.name||"")}</h2>
  <p><b>Fecha:</b> ${fmtLong(r.date)}</p><p><b>Horario:</b> ${r.start} – ${r.end}</p><p><b>Docente:</b> ${escapeHTML(teacherName(r.teacherId))}</p><p><b>Curso:</b> ${escapeHTML(r.course)}</p>
  <p><b>Actividad:</b> ${escapeHTML(r.activity||"Sin especificar")}</p><p><b>Estado:</b> <span class="status approved">${escapeHTML(r.status)}</span></p><p><b>Observaciones:</b> ${escapeHTML(r.notes||"Sin observaciones")}</p>`;
  $("#detailModal").classList.remove("hidden");
}

function renderCalendar(){
  const y=calendarDate.getFullYear(),m=calendarDate.getMonth(),first=new Date(y,m,1),days=new Date(y,m+1,0).getDate();
  let start=(first.getDay()+6)%7, cells=[];
  for(let i=0;i<start;i++)cells.push(`<div class="calendar-cell muted-day"></div>`);
  for(let d=1;d<=days;d++){
    const iso=dateISO(new Date(y,m,d)), events=visibleReservations().filter(r=>r.date===iso).sort((a,b)=>a.start.localeCompare(b.start));
    cells.push(`<div class="calendar-cell ${iso===todayISO()?"today":""}" data-calendar-date="${iso}"><div class="day-number">${d}</div>${events.slice(0,3).map(r=>`<div class="calendar-event" data-detail="${r.id}">${r.start} · ${escapeHTML(roomById(r.roomId)?.name||"")}</div>`).join("")}${events.length>3?`<small>+${events.length-3} más</small>`:""}</div>`);
  }
  while(cells.length%7)cells.push(`<div class="calendar-cell muted-day"></div>`);
  $("#calendarMonth").textContent=calendarDate.toLocaleDateString("es-AR",{month:"long",year:"numeric"});
  $("#calendarGrid").innerHTML=cells.join("");
}
function renderAgenda(){
  const rooms=data.rooms, base=new Date(agendaDate);
  if(agendaView==="day"){
    const iso=dateISO(base), hours=Array.from({length:14},(_,i)=>i+7);
    $("#agendaContent").innerHTML=`<div class="agenda-day-title"><b>${fmtLong(iso)}</b></div><div class="agenda-table">
      <div class="agenda-row agenda-head" style="--cols:${rooms.length}"><div>Hora</div>${rooms.map(r=>`<div>${escapeHTML(r.name)}</div>`).join("")}</div>
      ${hours.map(h=>{const hh=pad(h);return `<div class="agenda-row" style="--cols:${rooms.length}"><div class="agenda-time">${hh}:00</div>${rooms.map(room=>{const rs=visibleReservations().filter(r=>r.date===iso&&r.roomId===room.id&&r.start<=`${hh}:00`&&r.end>`...`);const exact=visibleReservations().find(r=>r.date===iso&&r.roomId===room.id&&r.start<=`${hh}:00`&&r.end>`${hh}:00`);return `<div>${exact&&exact.start===`${hh}:00`?`<div class="agenda-event" data-detail="${exact.id}"><strong>${exact.start}-${exact.end}</strong><small>${escapeHTML(exact.course)}</small></div>`:""}</div>`}).join("")}</div>`}).join("")}
    </div>`;
  }else{
    const monday=new Date(base);const dow=(monday.getDay()+6)%7;monday.setDate(monday.getDate()-dow);
    let html=`<div class="agenda-table"><div class="agenda-row agenda-head" style="--cols:7"><div>Hora</div>`;
    for(let i=0;i<7;i++){const d=new Date(monday);d.setDate(monday.getDate()+i);html+=`<div>${d.toLocaleDateString("es-AR",{weekday:"short",day:"numeric"})}</div>`} html+="</div>";
    for(let h=7;h<=20;h++){html+=`<div class="agenda-row" style="--cols:7"><div class="agenda-time">${pad(h)}:00</div>`;
      for(let i=0;i<7;i++){const d=new Date(monday);d.setDate(monday.getDate()+i);const iso=dateISO(d);const exact=visibleReservations().find(r=>r.date===iso&&r.start===`${pad(h)}:00`);html+=`<div>${exact?`<div class="agenda-event" data-detail="${exact.id}"><strong>${exact.start}-${exact.end}</strong><small>${escapeHTML(roomById(exact.roomId)?.name||"")}</small></div>`:""}</div>`}
      html+="</div>";
    } html+="</div>";$("#agendaContent").innerHTML=html;
  }
}
function shiftAgenda(delta){if(agendaView==="day")agendaDate.setDate(agendaDate.getDate()+delta);else agendaDate.setDate(agendaDate.getDate()+delta*7);renderAgenda()}

function renderRooms(){
  $("#roomsGrid").innerHTML=data.rooms.map(r=>`<article class="room-card"><div class="room-banner"><h3>${escapeHTML(r.name)}</h3><p>Capacidad: ${r.capacity} personas</p></div><div class="room-body"><p>${escapeHTML(r.description)}</p><div class="resource-list">${r.resources.map(x=>`<span class="resource">${escapeHTML(x)}</span>`).join("")}</div><div class="room-footer"><span class="status approved">Disponible para reserva</span>${isAdmin()?`<button class="row-action" data-edit-room="${r.id}">Editar</button>`:""}</div></div></article>`).join("");
}

function renderReports(){
  const rs=visibleReservations();$("#reportTotal").textContent=rs.length;
  const roomCounts={},teacherCounts={};rs.forEach(r=>{roomCounts[r.roomId]=(roomCounts[r.roomId]||0)+1;teacherCounts[r.teacherId]=(teacherCounts[r.teacherId]||0)+1});
  const topRoom=Object.entries(roomCounts).sort((a,b)=>b[1]-a[1])[0],topTeacher=Object.entries(teacherCounts).sort((a,b)=>b[1]-a[1])[0];
  $("#reportTopRoom").textContent=topRoom?roomById(topRoom[0])?.name:"—";$("#reportTopTeacher").textContent=topTeacher?teacherName(topTeacher[0]):"—";
  const max=Math.max(1,...Object.values(roomCounts));$("#roomBars").innerHTML=data.rooms.map(r=>`<div class="bar-row"><div class="bar-label"><span>${escapeHTML(r.name)}</span><b>${roomCounts[r.id]||0}</b></div><div class="bar-track"><div class="bar-fill" style="width:${((roomCounts[r.id]||0)/max)*100}%"></div></div></div>`).join("");
  const statuses={Aprobada:rs.filter(r=>r.status==="Aprobada").length,Finalizada:rs.filter(r=>r.status==="Finalizada").length};const maxS=Math.max(1,...Object.values(statuses));
  $("#statusBars").innerHTML=Object.entries(statuses).map(([k,v])=>`<div class="bar-row"><div class="bar-label"><span>${k}</span><b>${v}</b></div><div class="bar-track"><div class="bar-fill" style="width:${v/maxS*100}%"></div></div></div>`).join("");
}

function renderNotifications(){
  const notes=data.notices.slice(0,8);$("#notificationCount").textContent=notes.filter(n=>!n.read).length;
  $("#notificationPanel").innerHTML=notes.length?notes.map(n=>`<div class="notice">${escapeHTML(n.text)}<small>${new Date(n.date).toLocaleString("es-AR")}</small></div>`).join(""):`<div class="notice">No hay avisos.</div>`;
}

function renderAdmin(){
  if(!isAdmin())return;
  $("#adminUsers").innerHTML=`<div class="panel"><div class="admin-toolbar"><h3>Usuarios</h3><button class="btn btn-primary" data-action="new-user">＋ Nuevo usuario</button></div><div class="table-wrap"><table><thead><tr><th>Nombre</th><th>Usuario</th><th>Rol</th><th></th></tr></thead><tbody>${data.users.map(u=>`<tr><td>${escapeHTML(u.name)}</td><td>${escapeHTML(u.username)}</td><td>${escapeHTML(u.role)}</td><td><button class="row-action" data-edit-user="${u.id}">Editar</button></td></tr>`).join("")}</tbody></table></div></div>`;
  $("#adminRooms").innerHTML=`<div class="panel"><div class="admin-toolbar"><h3>Espacios</h3><button class="btn btn-primary" data-action="new-room">＋ Nuevo espacio</button></div><div class="table-wrap"><table><thead><tr><th>Espacio</th><th>Capacidad</th><th>Recursos</th><th></th></tr></thead><tbody>${data.rooms.map(r=>`<tr><td>${escapeHTML(r.name)}</td><td>${r.capacity}</td><td>${r.resources.length}</td><td><button class="row-action" data-edit-room="${r.id}">Editar</button></td></tr>`).join("")}</tbody></table></div></div>`;
  $("#adminCourses").innerHTML=`<div class="panel"><div class="admin-toolbar"><h3>Cursos</h3><button class="btn btn-primary" data-action="new-course">＋ Nuevo curso</button></div><div class="resource-list">${data.courses.map(c=>`<span class="resource">${escapeHTML(c)} <button class="tiny-remove" data-remove-course="${escapeHTML(c)}">×</button></span>`).join("")}</div></div>`;
}

function openAdminPrompt(type,id){
  if(!isAdmin())return;
  if(type==="user"){
    const u=id?userById(id):null;
    const name=prompt("Nombre completo:",u?.name||"");if(!name)return;
    const username=prompt("Usuario:",u?.username||"");if(!username)return;
    const password=prompt("Contraseña:",u?.password||"");if(!password)return;
    const role=prompt("Rol (Administrador / Docente / Directivo):",u?.role||"Docente");if(!["Administrador","Docente","Directivo"].includes(role))return showToast("Rol inválido.","error");
    if(u){Object.assign(u,{name,username,password,role})}else data.users.push({id:uid("u_"),name,username,password,role});
    saveData();renderAll();showToast("Usuario guardado.","success");
  }
  if(type==="room"){
    const r=id?roomById(id):null;
    const name=prompt("Nombre del espacio:",r?.name||"");if(!name)return;
    const description=prompt("Descripción:",r?.description||"")||"";
    const capacity=Number(prompt("Capacidad:",r?.capacity||30));if(!capacity)return;
    const resources=(prompt("Recursos separados por coma:",r?.resources?.join(", ")||"")||"").split(",").map(x=>x.trim()).filter(Boolean);
    if(r)Object.assign(r,{name,description,capacity,resources});else data.rooms.push({id:uid("r_"),name,description,capacity,resources});
    saveData();renderAll();showToast("Espacio guardado.","success");
  }
  if(type==="course"){
    const c=prompt("Nombre del curso:","");if(c&&!data.courses.includes(c.trim())){data.courses.push(c.trim());saveData();renderAll();showToast("Curso agregado.","success")}
  }
}
function removeCourse(c){if(confirm(`¿Eliminar el curso "${c}"?`)){data.courses=data.courses.filter(x=>x!==c);saveData();renderAll()}}

function closeModal(id){$(`#${id}`).classList.add("hidden")}

document.addEventListener("DOMContentLoaded",()=>{
  loadData();restoreSession();
  $("#loginForm").addEventListener("submit",e=>{e.preventDefault();login()});
  $("#logoutBtn").addEventListener("click",logout);
  $("#reservationForm").addEventListener("submit",createReservation);
  ["rDate","rRoom","rStart","rEnd"].forEach(id=>document.getElementById(id).addEventListener("input",checkAvailability));
  $$(".nav-item").forEach(b=>b.addEventListener("click",()=>goSection(b.dataset.section)));
  $("#menuBtn").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
  $("#notificationBtn").addEventListener("click",()=>{$("#notificationPanel").classList.toggle("hidden");data.notices.forEach(n=>n.read=true);saveData();renderNotifications()});
  $("#prevMonth").addEventListener("click",()=>{calendarDate.setMonth(calendarDate.getMonth()-1);renderCalendar()});
  $("#nextMonth").addEventListener("click",()=>{calendarDate.setMonth(calendarDate.getMonth()+1);renderCalendar()});
  $("#calendarToday").addEventListener("click",()=>{calendarDate=new Date();renderCalendar()});
  $("#prevAgenda").addEventListener("click",()=>shiftAgenda(-1));$("#nextAgenda").addEventListener("click",()=>shiftAgenda(1));$("#agendaToday").addEventListener("click",()=>{agendaDate=new Date();renderAgenda()});
  $$("[data-agenda-view]").forEach(b=>b.addEventListener("click",()=>{agendaView=b.dataset.agendaView;$$("[data-agenda-view]").forEach(x=>x.classList.toggle("active",x===b));renderAgenda()}));
  $("#reservationSearch").addEventListener("input",renderReservations);$("#reservationRoomFilter").addEventListener("change",renderReservations);$("#reservationStatusFilter").addEventListener("change",renderReservations);
  document.addEventListener("click",e=>{
    const sectionLink=e.target.closest("[data-section-link]");if(sectionLink)goSection(sectionLink.dataset.sectionLink);
    const action=e.target.closest("[data-action]")?.dataset.action;if(action==="new-reservation")openReservationModal();if(action==="new-room")openAdminPrompt("room");if(action==="new-user")openAdminPrompt("user");if(action==="new-course")openAdminPrompt("course");
    const detail=e.target.closest("[data-detail]");if(detail)showDetail(detail.dataset.detail);
    const del=e.target.closest("[data-delete]");if(del)deleteReservation(del.dataset.delete);
    const er=e.target.closest("[data-edit-room]");if(er)openAdminPrompt("room",er.dataset.editRoom);
    const eu=e.target.closest("[data-edit-user]");if(eu)openAdminPrompt("user",eu.dataset.editUser);
    const rc=e.target.closest("[data-remove-course]");if(rc)removeCourse(rc.dataset.removeCourse);
    const close=e.target.closest("[data-close]");if(close)closeModal(close.dataset.close);
    const at=e.target.closest("[data-admin-tab]");if(at){$$(".admin-tab").forEach(x=>x.classList.remove("active"));at.classList.add("active");$$(".admin-pane").forEach(x=>x.classList.add("hidden"));$(`#admin${at.dataset.adminTab.charAt(0).toUpperCase()+at.dataset.adminTab.slice(1)}`).classList.remove("hidden")}
  });
});
